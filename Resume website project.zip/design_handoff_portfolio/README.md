# Handoff: Amanda Santi — Developer Portfolio Site

## Overview
A single-page personal portfolio site for a Principal Software Developer. It presents a hero
introduction, an "at a glance" spec panel, current + past experience, a "Selected Work"
grid (personal projects with links + internal case studies without links), an
education & awards block, and a contact footer. Visual identity is a **dark "systems
blueprint" theme**: near-black background with a faint blueprint grid, monospace + geometric
type, and a single cyan accent.

The site is intended to be **statically hosted** (the author plans to host it on GitHub Pages
under `itchy-squid.github.io`). One personal project ("Set") is meant to be hosted **alongside
this site at the `/set` path**.

## About the Design Files
The file in this bundle (`Portfolio.dc.html`) is a **design reference created in HTML** — a
working prototype showing the intended look, content, and behavior. It is authored in a small
in-house component format ("Design Components": an `<x-dc>` template + a `class Component`
logic block). **Do not ship this file as-is.** The task is to **recreate this design in the
target environment** using its established patterns. For a static portfolio like this, plain
HTML/CSS/JS or a light static-site setup (Astro, 11ty, or a single React/Vite page) are all
reasonable — pick what fits the hosting plan. All content lives as plain data arrays in the
logic block and should be lifted directly.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and interactions are final. Recreate the UI
faithfully. Exact tokens are listed below.

## Layout & Structure
- Root: full-viewport dark surface. Content is centered in a **max-width 1080px** container
  with **32px horizontal padding**. Sections are separated by a `1px solid #21262d` top border.
- Section vertical padding: **64px top/bottom** (hero is `88px` top / `72px` bottom; contact is
  `80px`).
- Sticky top nav (see below). Smooth scrolling via anchor links to section ids.
- Font sources (Google Fonts): **Space Grotesk** (display/headings), **IBM Plex Sans** (body),
  **IBM Plex Mono** (labels, meta, tags, nav).

### Sections (in order)
1. **Nav** (`.site-nav`, sticky, `top:0`, z-index 50)
   - `rgba(13,17,23,.72)` background with `backdrop-filter: blur(10px)`, bottom border `#21262d`.
   - Left: mono logo `/ amanda.santi` (the `/` is accent-colored).
   - Right: mono links `work`, `projects`, `awards` (muted `#8b949e`, hover → accent) +
     a solid accent button **↓ Résumé PDF** (`color:#0d1117` on accent bg) that calls
     `window.print()`.
   - Hidden in print (`@media print { .site-nav, .no-print { display:none } }`).

2. **Hero** (`#top`) — 2-column grid `1.35fr / 1fr`, 56px gap, vertically centered.
   - Left column:
     - Mono kicker (accent): `// systems design · architecture · .NET · cloud`
     - `h1` name — Space Grotesk 600, **60px**, line-height 1.02, letter-spacing -0.02em, `#f0f6fc`.
     - Mono role subtitle — 14px, letter-spacing 0.22em, uppercase, `#8b949e`.
     - Blurb `<p>` — IBM Plex Sans 16px, line-height 1.65, `#b3bcc6`, max-width 52ch.
     - Two buttons: **View projects →** (solid accent, dark text, links `#projects`) and
       **Get in touch** (outline `1px #2a323d`, links `mailto:`).
     - One contact line (mono 12px): a single LinkedIn link (`in linkedin.com/in/amandasanti`).
   - Right column: **"at_a_glance" panel** (`.no-print`) — `1px solid #21262d`, radius 12px,
     `rgba(19,26,36,.6)` bg, 22px padding. Header row: `at_a_glance` (muted) + `● open to talk`
     (accent), bottom border. Then key→value rows: mono key (accent, width 88px) + value
     (`#f0f6fc`). Values: experience → `15+ years`, focus → `Systems design & architecture`,
     cloud → `Azure · Functions · Bicep`, stack → `.NET · C# · SQL / EF`, status → `Employed`.

3. **Work** (`#work`)
   - Section label (mono, accent, uppercase): `▹ current_role`.
   - **Featured current-role card**: `1px solid #21262d`, radius 12px, subtle accent gradient
     `linear-gradient(160deg, rgba(67,217,200,.06), rgba(19,26,36,.5))`, 32px padding.
     - Header: role (Space Grotesk 600, 24px, `#f0f6fc`) + company (mono, `#8b949e`) on the left;
       period pill on the right (mono 12px, dark text on accent bg, radius 999px).
     - Bullets: accent `–` marker + IBM Plex Sans 14.5px, line-height 1.7, `#b3bcc6`.
       Optional tag chips per bullet (mono 11px, accent text, `1px solid rgba(67,217,200,.35)`,
       radius 4px).
   - **"Previously" list**: label (mono, `#8b949e`), then rows separated by `1px solid #21262d`:
     role (Space Grotesk 500, 16px) + `· company` (mono, muted) on the left, period (mono, accent)
     on the right.

4. **Selected Work** (`#projects`)
   - Header row: `▹ selected_work` (accent) + `case studies + personal projects` (muted).
   - **2-column grid**, 20px gap. Each card: `1px solid #21262d`, radius 12px, `rgba(19,26,36,.5)`
     bg, 24px padding, column flex. **Hover:** `border-color` → accent and `translateY(-4px)`
     (transition `.55s`, border `.2s`).
     - Top row: tag (mono 11px, accent) + year (mono 11px, muted) space-between.
     - Title: Space Grotesk 600, 19px, `#f0f6fc`.
     - Desc: IBM Plex Sans 13.5px, line-height 1.6, `#b3bcc6`, `flex:1`.
     - Stack chips: mono 10.5px, `#8b949e`, `1px solid #2a323d`, radius 4px.
     - Footer (conditional): if the project **has links**, a top-bordered row with
       `→ live demo` and/or `→ source` (each rendered only if present; hover → accent).
       If the project is **internal**, instead show a muted line `◆ internal · walkthrough on request`.

5. **Education & Awards** (`#awards`) — 2-column grid `1fr / 1.15fr`, 48px gap.
   - Education: label `▹ education`, school (Space Grotesk 600, 18px), degree (Plex Sans 14),
     years (mono, accent), detail (Plex Sans 13, muted, max-width 40ch).
   - Awards: label `▹ awards & recognition`, then rows separated by `1px solid #21262d`:
     year (mono, accent, width 44px) + [title · status (Space Grotesk 500, 14) / items (Plex Sans 12.5, muted)].

6. **Contact / Footer** (`#contact`) — centered.
   - Mono accent kicker `// let's build something reliable`, big heading **Get in touch**
     (Space Grotesk 600, 40px), a solid accent email button (`mailto:`), and a mono LinkedIn link.
   - Bottom bar (top border): `© 2026 Amanda Santi` and `designed & built for reliability`
     (mono 11px, `#5b6572`).

## Interactions & Behavior
- **Nav / hero anchors**: smooth-scroll to `#work`, `#projects`, `#awards` (via CSS
  `html { scroll-behavior: smooth }`; sections use `scroll-margin-top: 80px` for the sticky nav).
- **Résumé PDF button**: calls `window.print()`. Print CSS hides `.site-nav` and `.no-print`
  and avoids breaking cards across pages (`section { break-inside: avoid }`, `@page { margin: 0.5in }`).
- **Reveal-on-scroll**: every element marked `data-reveal` starts at `opacity:0;
  translateY(12px)` with a `.7s` ease transition, and is revealed when it scrolls into view via
  `IntersectionObserver` (threshold ~0.05). Provide a **fallback** that reveals everything after
  a short timeout (and immediately if `IntersectionObserver` is unavailable) so content is never
  stuck hidden.
- **Card hover**: project cards lift and their border turns accent; links and nav items shift to
  accent on hover.
- Links are real anchors: contact = `mailto:` / LinkedIn URL; project live/source = external URLs
  (`target="_blank"`), except Set's live link which is a same-origin path (`/set`).

## Responsive Behavior
The prototype is desktop-first (fixed 2-column hero, 2-column project grid, 2-column
edu/awards). For production, collapse each 2-column grid to a single column on narrow
viewports (~≤760px), stack the hero (panel below the text), and let the nav links wrap or move
into a menu. Type scale can stay; reduce the hero `h1` on small screens.

## State Management
Effectively static. All content is data (arrays/objects) rendered into the markup — no runtime
data fetching. The only stateful behavior is the scroll-reveal observer and the print action.
Two "theme" knobs exist in the prototype and can be dropped or kept as build-time config:
- `accent` (default `#43d9c8`) — the single accent color, applied via a CSS custom property
  `--accent` so all accent usages read `var(--accent, #43d9c8)`.
- `gridBackground` (default `true`) — toggles the blueprint grid background image.

## Design Tokens
Colors:
- Background base: `#0d1117`
- Panel/surface: `#131a24` / `rgba(19,26,36,.5–.6)`
- Borders / dividers: `#21262d`; secondary border `#2a323d`
- Text — primary heading: `#f0f6fc`; body: `#c9d1d9` / `#b3bcc6`; muted: `#8b949e`; faint: `#5b6572`
- Accent (cyan): `#43d9c8` (on-accent text uses `#0d1117`); accent tints
  `rgba(67,217,200,.05–.35)`
- Blueprint grid lines: `rgba(255,255,255,.035)`, `background-size: 28px 28px`
- Selection: bg `#43d9c8`, text `#0d1117`

Typography:
- Display/headings: **Space Grotesk** (500/600)
- Body: **IBM Plex Sans** (400/500)
- Mono (labels, meta, tags, nav, kicker): **IBM Plex Mono** (400/500/600)
- Key sizes: hero h1 60px; section heading (contact) 40px; card title 19px; role 24px; body
  14–16px; mono labels 11–13px. Uppercase mono labels use letter-spacing 0.08–0.22em.

Radius: cards/panels 12px; pills/chips 4–6px; full pill 999px.
Spacing: container max-width 1080px, 32px gutters; section padding 64px; grid gaps 20–56px.
Shadow: minimal (the prototype relies on borders/gradients, not drop shadows).

## Assets
- **No image assets.** All iconography is typographic/geometric (mono glyphs `▹ ◆ – ● //`,
  a small accent square bullet, CSS pill/border shapes). No SVG illustrations.
- Fonts loaded from Google Fonts (Space Grotesk, IBM Plex Sans, IBM Plex Mono).
- The "Set" game is a **separate app** expected at `/set` on the same host — not part of this
  bundle.

## External links used
- LinkedIn: `https://www.linkedin.com/in/amandasanti`
- Email: `amanda.santi@live.com`
- Set — live: `/set` (same-origin); source: `https://github.com/itchy-squid/itchy-squid.github.io/tree/master/set`
- Advent of Code — source: `https://github.com/itchy-squid/AdventOfCode`
- Database Tycoon — live: `https://asanti.itch.io/database-tycoon`; source: `https://github.com/itchy-squid/game-jam/tree/main/Database%20Tycoon`

## Content (verbatim, for lifting)
**Name:** Amanda Santi — **Title:** Software Engineer
**Hero blurb:** "I build robust, scalable system architectures — over 15 years across systems
design, .NET, and cloud. I'm at my best taking a vague idea, mapping the roadmap to make it
enterprise-ready, and rallying a team to deliver it."

**Experience**
- **Principal Software Developer**, HCSS, 2024 – Present
  - Establishing the company data warehouse on Databricks — building pipelines that read from
    thousands of source databases and sync them to Parquet, packaged as Databricks Asset Bundles
    for repeatable, versioned deployment. `[Databricks, Python, Asset Bundles, Parquet]`
  - Building a framework that lets internal teams safely take AI-assisted "vibe code" apps to
    production on their own — giving non-specialist teams the guardrails, testing, and review
    standards to self-serve their internal tools with confidence. `[Platform, CI/CD, Governance]`
  - Driving site reliability across the product suite — owning database maintenance, serving on
    the architecture review committee and helping teams prepare for reviews, and running fire
    drills to keep systems dependable at scale. `[SRE, Database, Architecture]`
- **Senior DevOps Specialist**, HCSS, 2023 – 2024 (shown in "Previously")
- **Supervisor**, HCSS, 2022 – 2023 (shown in "Previously")
- **Senior Software Developer**, HCSS, 2018 – 2022 (shown in "Previously")

**Selected Work** (order: newest → oldest)
- **Advent of Code** — 2020 – present — personal. "Every year since 2020 — a running record of
  how I break down algorithmic puzzles. Source on GitHub; no live demo by nature."
  `[Python, Algorithms]` — source link only.
- **Database Tycoon** — 2024 — personal. "A silly game-jam entry — built fast and for fun,
  because not everything has to be enterprise-grade." `[Game Jam, Godot]` — live + source.
  *(NOTE: confirm the engine tag "Godot" with the author — it was an assumption.)*
- **Set — the card game** — 2023 — personal. "A browser build of the pattern-matching game Set,
  with clean, responsive gameplay — hosted right here on this site." `[JavaScript, UI]` —
  live (`/set`) + source.
- **Nightly DB Maintenance Engine** — 2023 — internal case study (HCSS). "Serverless system that
  runs maintenance across thousands of databases nightly and flags query-performance regressions
  before they reach production." `[Azure Functions, Bicep, SQL]` — no links; shows "internal".

**Education:** B.S. in Computer Science, Carnegie Mellon University, 2004 – 2008. "Capstone pair
project included implementation of an x86-based kernel with threading library and drivers. (C, ASM)"

**Awards & recognition**
- 2025 — HCSS Devvy Award, Winner — Champion Archivist
- 2024 — HCSS Devvy Award, Winner — Glue Award
- 2024 — HCSS Ideas Cup, Winner — Impact · Best in Show
- 2023 — HCSS Devvy Award, Winner — Outsider of the Year
- 2022 — HCSS Devvy Award, Nominee — Glue Award · Persistence Award
- 2021 — HCSS Devvy Award, Nominee — Emerging Leader · Persistence Award · Unsung Hero
- 2020 — HCSS Devvy Award, Nominee — Emerging Leader · Pathfinder
- 2020 — HCSS Ideas Cup, Winner — Efficiency Award

## Files
- `Portfolio.dc.html` — the full design reference (template + content data + interaction logic).
  All copy, links, tokens, and layout live here; use it as the source of truth alongside this README.
